package view;

public class ModeloTabela {
    
}

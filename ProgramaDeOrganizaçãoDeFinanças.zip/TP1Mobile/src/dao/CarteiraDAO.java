package dao;

import conexao.Conexao;
import entity.Carteira;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Maria Eduarda e Arthur Segheto
 */

//DAO para a manipulação de dados relacionados a entidade chamada "Carteira"
public class CarteiraDAO {

    private Conexao conexao;
    private Connection conn;

    //construtor é executado automaticamente sempre que um novo objeto for criado
    public CarteiraDAO() {
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }

    //inserir os dados
    public void inserir(Carteira carteira) {
        String sql = "INSERT INTO carteira(nome, classificacao, valor, data) VALUES " + "(?, ?, ?, ?)";

        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);

            stmt.setString(1, carteira.getNome());
            stmt.setString(2, carteira.getClassificacao());
            stmt.setDouble(3, carteira.getValor());
            stmt.setString(4, carteira.getData());

            stmt.execute();
            JOptionPane.showMessageDialog(null, "Inserido");
        } catch (Exception e) {
            System.out.println("Erro ao inserir dados." + e.getMessage());
        }
    }

    //listar todos os dados
    public List<Carteira> listarCarteira() {
        try {
            // criar vetor que vair armazenar os registros do banco
            List<Carteira> lista = new ArrayList<Carteira>();
            //criar comando sql
            String sql = "SELECT * from carteira";
            //Este comando seleciona todos os valores da tabela
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            //guarda resultado do select dentro do objeto rs
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Carteira c = new Carteira();
                c.setId(rs.getInt("id"));
                c.setNome(rs.getString("nome"));
                c.setClassificacao(rs.getString("classificacao"));
                c.setValor(rs.getDouble("valor"));
                c.setData(rs.getString("data"));

                lista.add(c);
            }
            return lista;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    //verifica se a tabela está vazia
    public boolean isVazio() {
        try {
            String sql = "SELECT COUNT(*) AS count FROM carteira";
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                int count = rs.getInt("count");
                return count == 0;
            }
            return true;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    //calcula o total de ganhos utilizando consultas no banco de dados
    public double calcularTotalGanhos() {
        double totalGanhos = 0.0;
        
        try {
            String sql = "SELECT SUM(valor) AS total_ganhos FROM carteira WHERE valor > 0";
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                totalGanhos = rs.getDouble("total_ganhos");
            }

            rs.close();
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Math.abs(totalGanhos); 
    }

    //calcula o total de gastos utilizando consultas no banco de dados
    public double calcularTotalGastos() {
        double totalGastos = 0.0;
        
        try {
            String sql = "SELECT SUM(valor) AS total_gastos FROM carteira WHERE valor < 0";
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                totalGastos = rs.getDouble("total_gastos");
            }

            rs.close();
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return Math.abs(totalGastos); 
    }

    //método para excluir dados selecionados do banco de dados
    public void excluir(Carteira carteira) {
        try {
            String sql = "delete from carteira where id = ?";
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setInt(1, carteira.getId());

            stmt.execute();
            stmt.close();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
